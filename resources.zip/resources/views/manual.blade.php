@extends('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('หน้าแรก')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="card">
        <div class="card-header card-header-rose">
          <h4 class="card-title">ยินดีต้อนรับเข้าสู่ระบบบริหารจัดการข้อสอบแบบตัวเลือกและกระบวนการสอบ</h4>
        </div>
      </div>
    </div>
  </div>
@endsection

@push('js')
  <script>
  </script>
@endpush