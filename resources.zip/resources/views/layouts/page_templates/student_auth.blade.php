<div class="wrapper ">
  <div class="main-panel">
    @include('layouts.navbars.navs.auth_student')
    @yield('content')
    {{--@include('layouts.footers.auth')--}}
  </div>
</div>